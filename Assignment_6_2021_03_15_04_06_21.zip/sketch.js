function setup() {
  createCanvas(600, 600);
background(220);
}

function draw() { 
  angleMode(DEGREES); // Change the mode to DEGREES
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 2, height / 2);
  push();
  rotate(a);
  rect(-20, -5, 40, 10); // Larger rectangle is rotating in degrees
  pop();
  angleMode(RADIANS); // Change the mode to RADIANS
  rotate(a); // variable a stays the same
  rect(-40, -5, 20, 10);
  rectMode(CENTER);
  translate(width / 2, height / 2);
  translate(p5.Vector.fromAngle(millis() / 2000, 300));
  rect(30, 20, 50, 50);
scale(0.5, 1.3);
rect(90, 70, 80, 80);
scale(0.5,2.3)
  let x = 10;
print('The value of x is ' + x);
}
for(let i = 0; i < 2; i++) {
  console.log(i);
}
  


 