function setup() {
  createCanvas(500, 500);
  background ('#fae')
  fill('purple')
  ellipse(400,400,80,80);
  fill('red')
  ellipse(100, 100, 80, 80);
  fill('blue')
  rect(175, 200, 150, 100);
}
let value = 0
function keyPressed() {
  if(keyCode === UP_ARROW) {
    fill('red')
    rect(175, 200, 150, 100);
 } else {
   fill('blue');
   rect(175, 200, 150, 100);}
}
function mousePressed() {
  if ((mouseX > 175) && (mouseX < 175+150) && (mouseY > 200) && (mouseY < 200+100)) 
  {fill('green')
  } else {
    fill('red');}
  ellipse(100, 100, 80, 80);
  if ((mouseX > 400) && (mouseX <400+80) &&(mouseY >400) && (mouseY < 400+80))
    {fill('yellow')
    } else { 
    fill('purple');}
  ellipse(400, 400, 80, 80);
}


  